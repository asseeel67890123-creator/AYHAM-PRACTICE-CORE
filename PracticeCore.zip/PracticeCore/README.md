# PracticeCore

Practice core for Paper 1.21.11 up to 26.2 (one jar). Every menu is a Dialog (no chest inventories).
Compiled against paper-api 1.21.11 with Java 21 bytecode, api-version 1.21.11. Servers on 26.x need Java 25 to run, the jar itself needs nothing extra.

## Build
    mvn clean package
Jar: target/PracticeCore-1.0.0.jar -> put it in plugins/. Java 21.

## Quick setup (in game, as OP)
1. /practice admin > Set Lobby
2. Arenas > Create arena > stand at the spots > Set Spawn 1 / Set Spawn 2
3. Put a kit in your inventory/armor/offhand > Kits > Create kit
4. Players: /practice or right-click the compass in the lobby

## Commands
/practice [menu|play|stats|cosmetics|leave|lobby]   permission practice.use (default true)
/practice admin | reload                            permission practice.admin (default op)

## Files (plugins/PracticeCore/)
- lang/en.yml, lang/ar.yml : every message, dialog title, button and tooltip (MiniMessage). Pick with `language:` in config.yml.
- gui.yml    : buttons of the main menu (also editable in game: Admin > GUI Manager)
- arenas.yml, kits.yml, profiles.yml, data.yml : data

## Button actions (gui.yml / GUI Manager)
close, menu:play, menu:cosmetics, menu:stats, menu:admin, menu:main, command:<cmd>
Labels can be MiniMessage or `lang:some.key`.

## Build with GitHub (no local setup)
Push the project to a GitHub repo. Actions builds it on every push:
Repo > Actions > latest run > Artifacts > PracticeCore (zip containing the jar).

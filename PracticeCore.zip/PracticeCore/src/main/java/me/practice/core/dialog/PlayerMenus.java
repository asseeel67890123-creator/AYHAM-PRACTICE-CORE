package me.practice.core.dialog;

import io.papermc.paper.dialog.Dialog;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.body.DialogBody;
import io.papermc.paper.registry.data.dialog.input.DialogInput;
import me.practice.core.PracticePlugin;
import me.practice.core.cosmetics.CosmeticsManager;
import me.practice.core.gui.GuiButton;
import me.practice.core.kit.Kit;
import me.practice.core.lang.LangManager;
import me.practice.core.profile.Profile;
import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

import static me.practice.core.lang.LangManager.ph;
import static me.practice.core.lang.LangManager.phc;

/** Every menu a normal player sees. All of them are Dialogs, no chest inventories. */
public final class PlayerMenus {

    private final PracticePlugin plugin;

    public PlayerMenus(PracticePlugin plugin) {
        this.plugin = plugin;
    }

    private LangManager lang() {
        return plugin.lang();
    }

    private DialogKit dk() {
        return plugin.dialogs();
    }

    private ActionButton back(Player ignored, java.util.function.Consumer<Player> target) {
        return dk().button(lang().t("dialogs.common.back"), null, target);
    }

    // ---------- main menu (built from gui.yml) ----------

    public void main(Player p) {
        List<ActionButton> buttons = new ArrayList<>();
        for (GuiButton g : plugin.gui().visibleFor(p)) {
            Component label = lang().parseOrLang(g.label);
            Component tip = g.tooltip == null || g.tooltip.isBlank() ? null : lang().parseOrLang(g.tooltip);
            if (g.action.equals("close")) {
                buttons.add(ActionButton.create(label, tip, DialogKit.BUTTON_WIDTH, null));
            } else {
                buttons.add(dk().button(label, tip, pl -> runAction(pl, g.action)));
            }
        }
        if (buttons.isEmpty()) buttons.add(dk().closeButton(lang().t("dialogs.common.close")));

        List<DialogBody> body = List.of(dk().message(lang().t("dialogs.main.subtitle", ph("player", p.getName()))));
        dk().open(p, dk().multi(lang().t("dialogs.main.title"), body, List.of(), buttons, 2));
    }

    private void runAction(Player p, String action) {
        if (action.startsWith("menu:")) {
            switch (action.substring(5)) {
                case "play" -> play(p);
                case "cosmetics" -> cosmetics(p);
                case "stats" -> stats(p);
                case "admin" -> {
                    if (p.hasPermission("practice.admin")) plugin.adminMenus().main(p);
                    else lang().send(p, "no-permission");
                }
                default -> main(p);
            }
        } else if (action.startsWith("command:")) {
            p.performCommand(action.substring(8));
        }
    }

    // ---------- play / queue ----------

    public void play(Player p) {
        if (plugin.matches().inMatch(p)) {
            lang().send(p, "queue.in-match");
            return;
        }
        List<ActionButton> buttons = new ArrayList<>();
        List<Kit> kits = plugin.kits().enabled();
        for (Kit k : kits) {
            Component name = lang().parse(k.displayName);
            Component label = lang().t("dialogs.play.kit-button", phc("kit", name));
            Component tip = lang().t("dialogs.play.kit-tooltip", phc("kit", name),
                    ph("queued", plugin.matches().queueSize(k.id)),
                    ph("playing", plugin.matches().playingCount(k.id)));
            buttons.add(dk().button(label, tip, pl -> plugin.matches().join(pl, k)));
        }
        if (plugin.matches().isQueued(p)) {
            buttons.add(dk().button(lang().t("dialogs.play.leave-queue"), null, pl -> plugin.matches().leave(pl)));
        }
        buttons.add(back(p, this::main));

        Component text = kits.isEmpty() ? lang().t("dialogs.play.no-kits") : lang().t("dialogs.play.body");
        dk().open(p, dk().multi(lang().t("dialogs.play.title"), List.of(dk().message(text)), List.of(), buttons, 2));
    }

    // ---------- cosmetics ----------

    public void cosmetics(Player p) {
        List<ActionButton> buttons = new ArrayList<>();
        buttons.add(dk().button(lang().t("dialogs.cosmetics.trim-button"), lang().t("dialogs.cosmetics.trim-tooltip"), this::trim));
        buttons.add(dk().button(lang().t("dialogs.cosmetics.shield-button"), lang().t("dialogs.cosmetics.shield-tooltip"), this::shield));
        buttons.add(back(p, this::main));
        dk().open(p, dk().multi(lang().t("dialogs.cosmetics.title"),
                List.of(dk().message(lang().t("dialogs.cosmetics.body"))), List.of(), buttons, 2));
    }

    private List<String> withNone(List<String> ids) {
        List<String> l = new ArrayList<>();
        l.add("none");
        l.addAll(ids);
        return l;
    }

    private Component niceName(String id) {
        return id.equals("none") ? lang().t("dialogs.common.none") : Component.text(CosmeticsManager.pretty(id));
    }

    public void trim(Player p) {
        Profile pr = plugin.profiles().get(p);
        CosmeticsManager cos = plugin.cosmetics();

        List<DialogBody> body = new ArrayList<>();
        body.add(dk().message(lang().t("dialogs.trim.body")));
        body.add(io.papermc.paper.registry.data.dialog.body.DialogBody.item(cos.previewTrim(pr)).build());

        List<DialogInput> inputs = new ArrayList<>();
        inputs.add(dk().options("pattern", lang().t("dialogs.trim.pattern"), withNone(cos.trimPatternIds()),
                pr.trimPattern, this::niceName));
        inputs.add(dk().options("material", lang().t("dialogs.trim.material"), withNone(cos.trimMaterialIds()),
                pr.trimMaterial, this::niceName));

        List<ActionButton> buttons = new ArrayList<>();
        buttons.add(dk().button(lang().t("dialogs.common.apply"), null, (pl, view) -> {
            String pattern = view.getText("pattern");
            String material = view.getText("material");
            if (pattern == null) pattern = "none";
            if (material == null) material = "none";
            Profile prof = plugin.profiles().get(pl);
            if (pattern.equals("none")) {
                prof.trimPattern = "none";
                prof.trimMaterial = "none";
                lang().send(pl, "cosmetics.trim-cleared");
            } else if (material.equals("none")) {
                lang().send(pl, "cosmetics.trim-incomplete");
            } else {
                prof.trimPattern = pattern;
                prof.trimMaterial = material;
                lang().send(pl, "cosmetics.trim-applied",
                        ph("pattern", CosmeticsManager.pretty(pattern)), ph("material", CosmeticsManager.pretty(material)));
            }
            plugin.profiles().save();
            trim(pl);
        }));
        buttons.add(dk().button(lang().t("dialogs.common.reset"), null, pl -> {
            Profile prof = plugin.profiles().get(pl);
            prof.trimPattern = "none";
            prof.trimMaterial = "none";
            plugin.profiles().save();
            lang().send(pl, "cosmetics.trim-cleared");
            trim(pl);
        }));
        buttons.add(back(p, this::cosmetics));
        dk().open(p, dk().multi(lang().t("dialogs.trim.title"), body, inputs, buttons, 2));
    }

    public void shield(Player p) {
        Profile pr = plugin.profiles().get(p);
        CosmeticsManager cos = plugin.cosmetics();
        int layers = Math.max(1, Math.min(5, plugin.getConfig().getInt("cosmetics.shield-layers", 3)));

        List<DialogBody> body = new ArrayList<>();
        body.add(dk().message(lang().t("dialogs.shield.body")));
        body.add(io.papermc.paper.registry.data.dialog.body.DialogBody.item(cos.previewShield(pr)).build());

        List<DialogInput> inputs = new ArrayList<>();
        inputs.add(dk().options("base", lang().t("dialogs.shield.base"), withNone(CosmeticsManager.dyeNames()),
                pr.shieldBase, this::niceName));
        for (int i = 1; i <= layers; i++) {
            String curPattern = "none";
            String curColor = "WHITE";
            if (pr.shieldLayers.size() >= i) {
                String[] parts = pr.shieldLayers.get(i - 1).split(":");
                if (parts.length == 2) {
                    curPattern = parts[0];
                    curColor = parts[1];
                }
            }
            inputs.add(dk().options("l" + i + "p", lang().t("dialogs.shield.layer-pattern", ph("n", i)),
                    withNone(cos.bannerPatternIds()), curPattern, this::niceName));
            inputs.add(dk().options("l" + i + "c", lang().t("dialogs.shield.layer-color", ph("n", i)),
                    CosmeticsManager.dyeNames(), curColor, this::niceName));
        }

        List<ActionButton> buttons = new ArrayList<>();
        buttons.add(dk().button(lang().t("dialogs.common.apply"), null, (pl, view) -> {
            Profile prof = plugin.profiles().get(pl);
            String base = view.getText("base");
            prof.shieldBase = base == null ? "none" : base;
            List<String> list = new ArrayList<>();
            for (int i = 1; i <= layers; i++) {
                String pat = view.getText("l" + i + "p");
                String col = view.getText("l" + i + "c");
                if (pat == null || pat.equals("none") || col == null) continue;
                list.add(pat + ":" + col);
            }
            prof.shieldLayers = list;
            plugin.profiles().save();
            lang().send(pl, "cosmetics.shield-applied");
            shield(pl);
        }));
        buttons.add(dk().button(lang().t("dialogs.common.reset"), null, pl -> {
            Profile prof = plugin.profiles().get(pl);
            prof.shieldBase = "none";
            prof.shieldLayers = new ArrayList<>();
            plugin.profiles().save();
            lang().send(pl, "cosmetics.shield-cleared");
            shield(pl);
        }));
        buttons.add(back(p, this::cosmetics));
        dk().open(p, dk().multi(lang().t("dialogs.shield.title"), body, inputs, buttons, 2));
    }

    // ---------- stats ----------

    public void stats(Player p) {
        Profile pr = plugin.profiles().get(p);
        Component text = lang().t("dialogs.stats.body",
                ph("wins", pr.wins), ph("losses", pr.losses), ph("played", pr.played()),
                ph("winrate", pr.winRate()), ph("streak", pr.streak), ph("best", pr.bestStreak));
        List<ActionButton> buttons = new ArrayList<>();
        buttons.add(back(p, this::main));
        buttons.add(dk().closeButton(lang().t("dialogs.common.close")));
        dk().open(p, dk().multi(lang().t("dialogs.stats.title", ph("player", p.getName())),
                List.of(dk().message(text)), List.of(), buttons, 2));
    }
}

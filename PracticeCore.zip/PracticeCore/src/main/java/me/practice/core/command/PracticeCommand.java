package me.practice.core.command;

import me.practice.core.PracticePlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public final class PracticeCommand implements CommandExecutor, TabCompleter {

    private final PracticePlugin plugin;

    public PracticeCommand(PracticePlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String sub = args.length == 0 ? "menu" : args[0].toLowerCase();

        if (sub.equals("reload")) {
            if (!sender.hasPermission("practice.admin")) {
                plugin.lang().send(sender, "no-permission");
                return true;
            }
            plugin.reloadAll();
            plugin.lang().send(sender, "reloaded");
            return true;
        }

        if (!(sender instanceof Player p)) {
            plugin.lang().send(sender, "players-only");
            return true;
        }

        switch (sub) {
            case "menu" -> plugin.playerMenus().main(p);
            case "play" -> plugin.playerMenus().play(p);
            case "stats" -> plugin.playerMenus().stats(p);
            case "cosmetics" -> plugin.playerMenus().cosmetics(p);
            case "leave" -> plugin.matches().leave(p);
            case "lobby", "spawn" -> {
                if (plugin.matches().inMatch(p)) {
                    plugin.lang().send(p, "queue.in-match");
                } else {
                    plugin.matches().leave(p);
                    plugin.toLobby(p);
                }
            }
            case "admin" -> {
                if (!p.hasPermission("practice.admin")) {
                    plugin.lang().send(p, "no-permission");
                } else {
                    plugin.adminMenus().main(p);
                }
            }
            default -> plugin.lang().send(p, "unknown-command");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length != 1) return out;
        List<String> subs = new ArrayList<>(List.of("menu", "play", "stats", "cosmetics", "leave", "lobby"));
        if (sender.hasPermission("practice.admin")) subs.addAll(List.of("admin", "reload"));
        for (String s : subs) if (s.startsWith(args[0].toLowerCase())) out.add(s);
        return out;
    }
}

package me.practice.core.arena;

import org.bukkit.Location;

public final class Arena {
    public final String id;
    public String displayName;
    public Location pos1;
    public Location pos2;
    public boolean enabled = true;

    public Arena(String id) {
        this.id = id;
        this.displayName = id;
    }

    public boolean ready() {
        return enabled && pos1 != null && pos2 != null && pos1.getWorld() != null && pos2.getWorld() != null;
    }
}

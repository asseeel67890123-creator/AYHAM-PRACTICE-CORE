package me.practice.core.profile;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class Profile {
    public final UUID id;
    public String name;

    public int wins;
    public int losses;
    public int streak;
    public int bestStreak;

    // Armor trim customizer ("none" = no trim)
    public String trimPattern = "none";
    public String trimMaterial = "none";

    // Shield customizer
    public String shieldBase = "none";            // DyeColor name or "none"
    public List<String> shieldLayers = new ArrayList<>(); // "pattern_id:DYE_COLOR"

    public Profile(UUID id, String name) {
        this.id = id;
        this.name = name;
    }

    public int played() {
        return wins + losses;
    }

    public int winRate() {
        return played() == 0 ? 0 : Math.round(wins * 100f / played());
    }
}

package me.practice.core.match;

import me.practice.core.PracticePlugin;
import me.practice.core.arena.Arena;
import me.practice.core.kit.Kit;
import me.practice.core.profile.Profile;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

import static me.practice.core.lang.LangManager.ph;
import static me.practice.core.lang.LangManager.phc;

/** Queues, 1v1 matches, countdowns and results. */
public final class MatchManager {

    private final PracticePlugin plugin;
    private final Map<String, LinkedList<UUID>> queues = new HashMap<>();
    private final Map<UUID, String> queued = new HashMap<>();
    private final Map<UUID, Match> inMatch = new HashMap<>();
    private final Set<String> busyArenas = new HashSet<>();
    private final Random random = new Random();

    public MatchManager(PracticePlugin plugin) {
        this.plugin = plugin;
    }

    // ---------- queries ----------

    public Match matchOf(Player p) {
        return inMatch.get(p.getUniqueId());
    }

    public boolean inMatch(Player p) {
        return inMatch.containsKey(p.getUniqueId());
    }

    public boolean isQueued(Player p) {
        return queued.containsKey(p.getUniqueId());
    }

    public int queueSize(String kitId) {
        LinkedList<UUID> q = queues.get(kitId);
        return q == null ? 0 : q.size();
    }

    public int playingCount(String kitId) {
        int n = 0;
        for (Match m : new HashSet<>(inMatch.values())) if (m.kit.id.equals(kitId)) n += 2;
        return n;
    }

    // ---------- queue ----------

    public void join(Player p, Kit kit) {
        if (inMatch(p)) {
            plugin.lang().send(p, "queue.in-match");
            return;
        }
        if (isQueued(p)) {
            plugin.lang().send(p, "queue.already");
            return;
        }
        if (!kit.enabled) {
            plugin.lang().send(p, "queue.kit-disabled");
            return;
        }
        queues.computeIfAbsent(kit.id, k -> new LinkedList<>()).add(p.getUniqueId());
        queued.put(p.getUniqueId(), kit.id);
        plugin.lang().send(p, "queue.joined", phc("kit", plugin.lang().parse(kit.displayName)));
        matchmake(kit.id);
    }

    public void leave(Player p) {
        String kitId = queued.remove(p.getUniqueId());
        if (kitId == null) {
            plugin.lang().send(p, "queue.not-queued");
            return;
        }
        LinkedList<UUID> q = queues.get(kitId);
        if (q != null) q.remove(p.getUniqueId());
        plugin.lang().send(p, "queue.left");
    }

    private void silentLeave(UUID id) {
        String kitId = queued.remove(id);
        if (kitId == null) return;
        LinkedList<UUID> q = queues.get(kitId);
        if (q != null) q.remove(id);
    }

    private void matchmakeAll() {
        for (String kitId : new ArrayList<>(queues.keySet())) matchmake(kitId);
    }

    private void matchmake(String kitId) {
        Kit kit = plugin.kits().get(kitId);
        LinkedList<UUID> q = queues.get(kitId);
        if (kit == null || q == null) return;

        // drop offline players
        q.removeIf(id -> {
            Player pl = Bukkit.getPlayer(id);
            if (pl == null) {
                queued.remove(id);
                return true;
            }
            return false;
        });

        while (q.size() >= 2) {
            List<Arena> free = new ArrayList<>();
            for (Arena a : plugin.arenas().readyArenas()) if (!busyArenas.contains(a.id)) free.add(a);
            if (free.isEmpty()) {
                if (plugin.arenas().readyArenas().isEmpty()) {
                    for (UUID id : q) {
                        Player pl = Bukkit.getPlayer(id);
                        if (pl != null) plugin.lang().send(pl, "queue.no-arena");
                    }
                }
                return;
            }
            Player p1 = Bukkit.getPlayer(q.poll());
            Player p2 = Bukkit.getPlayer(q.poll());
            if (p1 != null) queued.remove(p1.getUniqueId());
            if (p2 != null) queued.remove(p2.getUniqueId());
            if (p1 == null || p2 == null) {
                // put the one still online back
                Player left = p1 != null ? p1 : p2;
                if (left != null) {
                    q.addFirst(left.getUniqueId());
                    queued.put(left.getUniqueId(), kitId);
                }
                continue;
            }
            start(kit, free.get(random.nextInt(free.size())), p1, p2);
        }
    }

    // ---------- match lifecycle ----------

    private void start(Kit kit, Arena arena, Player p1, Player p2) {
        Match m = new Match(kit, arena, p1.getUniqueId(), p2.getUniqueId());
        inMatch.put(p1.getUniqueId(), m);
        inMatch.put(p2.getUniqueId(), m);
        busyArenas.add(arena.id);

        prepare(p1, m, arena.pos1);
        prepare(p2, m, arena.pos2);

        plugin.lang().send(p1, "match.found", ph("opponent", p2.getName()),
                phc("kit", plugin.lang().parse(kit.displayName)), phc("arena", plugin.lang().parse(arena.displayName)));
        plugin.lang().send(p2, "match.found", ph("opponent", p1.getName()),
                phc("kit", plugin.lang().parse(kit.displayName)), phc("arena", plugin.lang().parse(arena.displayName)));

        m.counter = Math.max(1, plugin.getConfig().getInt("match.countdown-seconds", 5));
        final int maxSeconds = plugin.getConfig().getInt("match.max-duration-seconds", 600);
        m.task = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            Player a = Bukkit.getPlayer(m.a);
            Player b = Bukkit.getPlayer(m.b);
            if (m.state == Match.State.COUNTDOWN) {
                if (m.counter > 0) {
                    for (Player pl : new Player[]{a, b}) {
                        if (pl == null) continue;
                        pl.showTitle(Title.title(plugin.lang().t("titles.countdown", ph("seconds", m.counter)),
                                plugin.lang().t("titles.countdown-sub")));
                        pl.playSound(pl.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 1f, 1f);
                    }
                    m.counter--;
                } else {
                    m.state = Match.State.ACTIVE;
                    for (Player pl : new Player[]{a, b}) {
                        if (pl == null) continue;
                        pl.showTitle(Title.title(plugin.lang().t("titles.go"), Component.empty()));
                        pl.playSound(pl.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.5f);
                    }
                }
            } else if (m.state == Match.State.ACTIVE) {
                m.elapsed++;
                if (maxSeconds > 0 && m.elapsed >= maxSeconds) end(m, null);
            }
        }, 20L, 20L);
    }

    private void prepare(Player p, Match m, org.bukkit.Location spawn) {
        silentLeave(p.getUniqueId());
        p.closeDialog();
        p.setGameMode(GameMode.SURVIVAL);
        p.setFireTicks(0);
        for (PotionEffect e : p.getActivePotionEffects()) p.removePotionEffect(e.getType());
        p.teleport(spawn);
        p.setHealth(p.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue());
        p.setFoodLevel(20);
        p.setSaturation(20f);
        plugin.kits().apply(p, m.kit, plugin.profiles().get(p));
        p.updateInventory();
    }

    /** Called when the loser reached lethal damage, or on quit / timeout (winner may be null for a draw). */
    public void end(Match m, Player winner) {
        if (m.state == Match.State.ENDED) return;
        m.state = Match.State.ENDED;
        if (m.task != null) m.task.cancel();

        Player a = Bukkit.getPlayer(m.a);
        Player b = Bukkit.getPlayer(m.b);

        if (winner != null) {
            UUID loserId = m.opponent(winner.getUniqueId());
            Player loser = Bukkit.getPlayer(loserId);
            Profile wp = plugin.profiles().get(winner);
            wp.wins++;
            wp.streak++;
            wp.bestStreak = Math.max(wp.bestStreak, wp.streak);
            Profile lp = plugin.profiles().byId(loserId);
            if (lp != null) {
                lp.losses++;
                lp.streak = 0;
            }
            String loserName = lp != null ? lp.name : "?";
            plugin.lang().send(winner, "match.won", ph("opponent", loserName));
            winner.showTitle(Title.title(plugin.lang().t("titles.victory"), plugin.lang().t("titles.victory-sub", ph("opponent", loserName))));
            if (loser != null) {
                loser.setGameMode(GameMode.SPECTATOR);
                plugin.lang().send(loser, "match.lost", ph("opponent", winner.getName()));
                loser.showTitle(Title.title(plugin.lang().t("titles.defeat"), plugin.lang().t("titles.defeat-sub", ph("opponent", winner.getName()))));
            }
        } else {
            for (Player pl : new Player[]{a, b}) {
                if (pl != null) plugin.lang().send(pl, "match.draw");
            }
        }
        plugin.profiles().save();

        long delay = Math.max(1, plugin.getConfig().getInt("match.end-delay-seconds", 3)) * 20L;
        Bukkit.getScheduler().runTaskLater(plugin, () -> finish(m), delay);
    }

    private void finish(Match m) {
        for (UUID id : new UUID[]{m.a, m.b}) {
            if (inMatch.get(id) == m) inMatch.remove(id);
            Player pl = Bukkit.getPlayer(id);
            if (pl != null) plugin.toLobby(pl);
        }
        busyArenas.remove(m.arena.id);
        matchmakeAll();
    }

    /** Lethal damage was intercepted by the listener. */
    public void handleLethal(Player victim) {
        Match m = matchOf(victim);
        if (m == null || m.state != Match.State.ACTIVE) return;
        Player winner = Bukkit.getPlayer(m.opponent(victim.getUniqueId()));
        end(m, winner);
    }

    public void handleQuit(Player p) {
        silentLeave(p.getUniqueId());
        Match m = matchOf(p);
        if (m == null) return;
        if (m.state != Match.State.ENDED) {
            Player winner = Bukkit.getPlayer(m.opponent(p.getUniqueId()));
            if (winner != null) plugin.lang().send(winner, "match.opponent-left", ph("opponent", p.getName()));
            end(m, winner);
        }
        inMatch.remove(p.getUniqueId());
    }

    /** Server stop / reload: send everyone home. */
    public void shutdown() {
        for (Match m : new HashSet<>(inMatch.values())) {
            if (m.task != null) m.task.cancel();
            for (UUID id : new UUID[]{m.a, m.b}) {
                Player pl = Bukkit.getPlayer(id);
                if (pl != null) plugin.toLobby(pl);
            }
        }
        inMatch.clear();
        busyArenas.clear();
        queues.clear();
        queued.clear();
    }
}

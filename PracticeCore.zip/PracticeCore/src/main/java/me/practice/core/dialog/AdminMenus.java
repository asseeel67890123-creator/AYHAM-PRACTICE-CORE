package me.practice.core.dialog;

import io.papermc.paper.dialog.DialogResponseView;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.body.DialogBody;
import io.papermc.paper.registry.data.dialog.input.DialogInput;
import me.practice.core.PracticePlugin;
import me.practice.core.arena.Arena;
import me.practice.core.arena.ArenaManager;
import me.practice.core.gui.GuiButton;
import me.practice.core.kit.Kit;
import me.practice.core.lang.LangManager;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

import static me.practice.core.lang.LangManager.ph;
import static me.practice.core.lang.LangManager.phc;

/** Admin tools: arenas, kits, in-game GUI manager. Everything is a Dialog. */
public final class AdminMenus {

    private final PracticePlugin plugin;

    public AdminMenus(PracticePlugin plugin) {
        this.plugin = plugin;
    }

    private LangManager lang() {
        return plugin.lang();
    }

    private DialogKit dk() {
        return plugin.dialogs();
    }

    private boolean denied(Player p) {
        if (p.hasPermission("practice.admin")) return false;
        lang().send(p, "no-permission");
        return true;
    }

    private ActionButton back(Consumer<Player> target) {
        return dk().button(lang().t("dialogs.common.back"), null, target);
    }

    private Component yesNo(boolean v) {
        return lang().t(v ? "dialogs.common.yes" : "dialogs.common.no");
    }

    // ---------- admin home ----------

    public void main(Player p) {
        if (denied(p)) return;
        List<ActionButton> b = new ArrayList<>();
        b.add(dk().button(lang().t("dialogs.admin.arenas"), lang().t("dialogs.admin.arenas-tip"), this::arenaList));
        b.add(dk().button(lang().t("dialogs.admin.kits"), lang().t("dialogs.admin.kits-tip"), this::kitList));
        b.add(dk().button(lang().t("dialogs.admin.gui"), lang().t("dialogs.admin.gui-tip"), this::guiList));
        b.add(dk().button(lang().t("dialogs.admin.set-lobby"), lang().t("dialogs.admin.set-lobby-tip"), pl -> {
            plugin.setLobby(pl.getLocation());
            lang().send(pl, "admin.lobby-set");
            main(pl);
        }));
        b.add(dk().button(lang().t("dialogs.admin.reload"), lang().t("dialogs.admin.reload-tip"), pl -> {
            plugin.reloadAll();
            lang().send(pl, "reloaded");
            main(pl);
        }));
        b.add(back(pl -> plugin.playerMenus().main(pl)));
        dk().open(p, dk().multi(lang().t("dialogs.admin.title"),
                List.of(dk().message(lang().t("dialogs.admin.body"))), List.of(), b, 2));
    }

    // =====================================================================
    //                               ARENAS
    // =====================================================================

    private Component arenaState(Arena a) {
        if (!a.enabled) return lang().t("dialogs.arenas.state-disabled");
        if (!a.ready()) return lang().t("dialogs.arenas.state-incomplete");
        return lang().t("dialogs.arenas.state-ready");
    }

    public void arenaList(Player p) {
        if (denied(p)) return;
        List<ActionButton> b = new ArrayList<>();
        for (Arena a : plugin.arenas().all()) {
            Component label = lang().t("dialogs.arenas.entry", ph("arena", a.id), phc("state", arenaState(a)));
            b.add(dk().button(label, null, pl -> arenaEdit(pl, a)));
        }
        b.add(dk().button(lang().t("dialogs.arenas.create"), null, this::arenaCreate));
        b.add(back(this::main));
        Component text = plugin.arenas().all().isEmpty() ? lang().t("dialogs.arenas.empty") : lang().t("dialogs.arenas.body");
        dk().open(p, dk().multi(lang().t("dialogs.arenas.title"), List.of(dk().message(text)), List.of(), b, 2));
    }

    public void arenaCreate(Player p) {
        if (denied(p)) return;
        List<DialogInput> inputs = List.of(dk().text("name", lang().t("dialogs.arenas.name-label"), "", 24));
        List<ActionButton> b = new ArrayList<>();
        b.add(dk().button(lang().t("dialogs.common.create"), null, (pl, view) -> {
            String id = clean(view.getText("name"));
            if (!id.matches("[a-z0-9_-]{2,24}")) {
                lang().send(pl, "arena.invalid-name");
                arenaCreate(pl);
                return;
            }
            if (plugin.arenas().get(id) != null) {
                lang().send(pl, "arena.exists", ph("arena", id));
                arenaCreate(pl);
                return;
            }
            Arena a = plugin.arenas().create(id);
            lang().send(pl, "arena.created", ph("arena", id));
            arenaEdit(pl, a);
        }));
        b.add(back(this::arenaList));
        dk().open(p, dk().multi(lang().t("dialogs.arenas.create-title"),
                List.of(dk().message(lang().t("dialogs.arenas.create-body"))), inputs, b, 2));
    }

    private void applyArenaInputs(Arena a, DialogResponseView view) {
        String display = view.getText("display");
        if (display != null && !display.isBlank()) a.displayName = display.trim();
        Boolean en = view.getBoolean("enabled");
        if (en != null) a.enabled = en;
    }

    public void arenaEdit(Player p, Arena a) {
        if (denied(p)) return;
        Component info = lang().t("dialogs.arena-edit.body", ph("arena", a.id),
                phc("state", arenaState(a)), ph("pos1", ArenaManager.fmt(a.pos1)), ph("pos2", ArenaManager.fmt(a.pos2)));
        List<DialogInput> inputs = new ArrayList<>();
        inputs.add(dk().text("display", lang().t("dialogs.arena-edit.display"), a.displayName, 40));
        inputs.add(dk().bool("enabled", lang().t("dialogs.arena-edit.enabled"), a.enabled));

        List<ActionButton> b = new ArrayList<>();
        b.add(dk().button(lang().t("dialogs.common.save"), null, (pl, view) -> {
            applyArenaInputs(a, view);
            plugin.arenas().save();
            lang().send(pl, "arena.saved", ph("arena", a.id));
            arenaEdit(pl, a);
        }));
        b.add(dk().button(lang().t("dialogs.arena-edit.set-pos1"), lang().t("dialogs.arena-edit.set-pos-tip"), (pl, view) -> {
            applyArenaInputs(a, view);
            a.pos1 = pl.getLocation().clone();
            plugin.arenas().save();
            lang().send(pl, "arena.pos-set", ph("pos", "1"), ph("arena", a.id));
            arenaEdit(pl, a);
        }));
        b.add(dk().button(lang().t("dialogs.arena-edit.set-pos2"), lang().t("dialogs.arena-edit.set-pos-tip"), (pl, view) -> {
            applyArenaInputs(a, view);
            a.pos2 = pl.getLocation().clone();
            plugin.arenas().save();
            lang().send(pl, "arena.pos-set", ph("pos", "2"), ph("arena", a.id));
            arenaEdit(pl, a);
        }));
        b.add(dk().button(lang().t("dialogs.arena-edit.teleport"), null, pl -> {
            if (a.pos1 != null && a.pos1.getWorld() != null) {
                pl.teleport(a.pos1);
            } else {
                lang().send(pl, "arena.no-pos");
            }
        }));
        b.add(dk().button(lang().t("dialogs.common.delete"), null, pl -> arenaDelete(pl, a)));
        b.add(back(this::arenaList));
        dk().open(p, dk().multi(lang().t("dialogs.arena-edit.title", ph("arena", a.id)),
                List.of(dk().message(info)), inputs, b, 2));
    }

    private void arenaDelete(Player p, Arena a) {
        ActionButton yes = dk().button(lang().t("dialogs.common.confirm"), null, pl -> {
            plugin.arenas().delete(a.id);
            lang().send(pl, "arena.deleted", ph("arena", a.id));
            arenaList(pl);
        });
        ActionButton no = dk().button(lang().t("dialogs.common.cancel"), null, pl -> arenaEdit(pl, a));
        dk().open(p, dk().confirm(lang().t("dialogs.arenas.delete-title"),
                lang().t("dialogs.arenas.delete-body", ph("arena", a.id)), yes, no));
    }

    // =====================================================================
    //                                KITS
    // =====================================================================

    public void kitList(Player p) {
        if (denied(p)) return;
        List<ActionButton> b = new ArrayList<>();
        for (Kit k : plugin.kits().all()) {
            Component label = lang().t("dialogs.kits.entry", ph("kit", k.id), phc("state", yesNo(k.enabled)));
            b.add(dk().button(label, null, pl -> kitEdit(pl, k)));
        }
        b.add(dk().button(lang().t("dialogs.kits.create"), lang().t("dialogs.kits.create-tip"), this::kitCreate));
        b.add(back(this::main));
        Component text = plugin.kits().all().isEmpty() ? lang().t("dialogs.kits.empty") : lang().t("dialogs.kits.body");
        dk().open(p, dk().multi(lang().t("dialogs.kits.title"), List.of(dk().message(text)), List.of(), b, 2));
    }

    public void kitCreate(Player p) {
        if (denied(p)) return;
        List<DialogInput> inputs = List.of(dk().text("name", lang().t("dialogs.kits.name-label"), "", 24));
        List<ActionButton> b = new ArrayList<>();
        b.add(dk().button(lang().t("dialogs.common.create"), null, (pl, view) -> {
            String id = clean(view.getText("name"));
            if (!id.matches("[a-z0-9_-]{2,24}")) {
                lang().send(pl, "kit.invalid-name");
                kitCreate(pl);
                return;
            }
            if (plugin.kits().get(id) != null) {
                lang().send(pl, "kit.exists", ph("kit", id));
                kitCreate(pl);
                return;
            }
            Kit k = plugin.kits().createFromPlayer(id, pl);
            lang().send(pl, "kit.created", ph("kit", id), ph("items", k.itemCount()));
            kitEdit(pl, k);
        }));
        b.add(back(this::kitList));
        dk().open(p, dk().multi(lang().t("dialogs.kits.create-title"),
                List.of(dk().message(lang().t("dialogs.kits.create-body"))), inputs, b, 2));
    }

    private void applyKitInputs(Kit k, DialogResponseView view) {
        String display = view.getText("display");
        if (display != null && !display.isBlank()) k.displayName = display.trim();
        String icon = view.getText("icon");
        if (icon != null && !icon.isBlank()) {
            Material m = Material.matchMaterial(icon.trim());
            if (m != null && m.isItem() && !m.isAir()) k.icon = m;
        }
        Boolean en = view.getBoolean("enabled");
        if (en != null) k.enabled = en;
        Boolean regen = view.getBoolean("regen");
        if (regen != null) k.regen = regen;
        Boolean hunger = view.getBoolean("hunger");
        if (hunger != null) k.hunger = hunger;
    }

    public void kitEdit(Player p, Kit k) {
        if (denied(p)) return;
        Component info = lang().t("dialogs.kit-edit.body", ph("kit", k.id), ph("items", k.itemCount()),
                ph("icon", k.icon.name()));
        List<DialogInput> inputs = new ArrayList<>();
        inputs.add(dk().text("display", lang().t("dialogs.kit-edit.display"), k.displayName, 60));
        inputs.add(dk().text("icon", lang().t("dialogs.kit-edit.icon"), k.icon.name(), 40));
        inputs.add(dk().bool("enabled", lang().t("dialogs.kit-edit.enabled"), k.enabled));
        inputs.add(dk().bool("regen", lang().t("dialogs.kit-edit.regen"), k.regen));
        inputs.add(dk().bool("hunger", lang().t("dialogs.kit-edit.hunger"), k.hunger));

        List<ActionButton> b = new ArrayList<>();
        b.add(dk().button(lang().t("dialogs.common.save"), null, (pl, view) -> {
            applyKitInputs(k, view);
            plugin.kits().save();
            lang().send(pl, "kit.saved", ph("kit", k.id));
            kitEdit(pl, k);
        }));
        b.add(dk().button(lang().t("dialogs.kit-edit.update-items"), lang().t("dialogs.kit-edit.update-items-tip"), (pl, view) -> {
            applyKitInputs(k, view);
            plugin.kits().copyFromPlayer(k, pl);
            plugin.kits().save();
            lang().send(pl, "kit.items-updated", ph("kit", k.id), ph("items", k.itemCount()));
            kitEdit(pl, k);
        }));
        b.add(dk().button(lang().t("dialogs.kit-edit.give"), lang().t("dialogs.kit-edit.give-tip"), pl -> {
            plugin.kits().apply(pl, k, plugin.profiles().get(pl));
            lang().send(pl, "kit.given", ph("kit", k.id));
        }));
        b.add(dk().button(lang().t("dialogs.common.delete"), null, pl -> kitDelete(pl, k)));
        b.add(back(this::kitList));
        dk().open(p, dk().multi(lang().t("dialogs.kit-edit.title", ph("kit", k.id)),
                List.of(dk().message(info)), inputs, b, 2));
    }

    private void kitDelete(Player p, Kit k) {
        ActionButton yes = dk().button(lang().t("dialogs.common.confirm"), null, pl -> {
            plugin.kits().delete(k.id);
            lang().send(pl, "kit.deleted", ph("kit", k.id));
            kitList(pl);
        });
        ActionButton no = dk().button(lang().t("dialogs.common.cancel"), null, pl -> kitEdit(pl, k));
        dk().open(p, dk().confirm(lang().t("dialogs.kits.delete-title"),
                lang().t("dialogs.kits.delete-body", ph("kit", k.id)), yes, no));
    }

    // =====================================================================
    //                           GUI MANAGER
    // =====================================================================

    public void guiList(Player p) {
        if (denied(p)) return;
        List<ActionButton> b = new ArrayList<>();
        int i = 1;
        for (GuiButton g : plugin.gui().all()) {
            Component label = lang().t("dialogs.gui.entry", ph("n", i++), ph("id", g.id), phc("state", yesNo(g.enabled)));
            b.add(dk().button(label, lang().t("dialogs.gui.entry-tip", ph("action", g.action)), pl -> guiEdit(pl, g)));
        }
        b.add(dk().button(lang().t("dialogs.gui.add"), null, this::guiAdd));
        b.add(dk().button(lang().t("dialogs.gui.preview"), lang().t("dialogs.gui.preview-tip"), pl -> plugin.playerMenus().main(pl)));
        b.add(back(this::main));
        dk().open(p, dk().multi(lang().t("dialogs.gui.title"),
                List.of(dk().message(lang().t("dialogs.gui.body"))), List.of(), b, 2));
    }

    public void guiAdd(Player p) {
        if (denied(p)) return;
        List<DialogInput> inputs = List.of(dk().text("id", lang().t("dialogs.gui.id-label"), "", 24));
        List<ActionButton> b = new ArrayList<>();
        b.add(dk().button(lang().t("dialogs.common.create"), null, (pl, view) -> {
            String id = clean(view.getText("id"));
            if (!id.matches("[a-z0-9_-]{2,24}")) {
                lang().send(pl, "gui.invalid-id");
                guiAdd(pl);
                return;
            }
            if (plugin.gui().get(id) != null) {
                lang().send(pl, "gui.exists", ph("id", id));
                guiAdd(pl);
                return;
            }
            GuiButton g = new GuiButton(id);
            g.label = "<white>" + id;
            plugin.gui().add(g);
            plugin.gui().save();
            lang().send(pl, "gui.created", ph("id", id));
            guiEdit(pl, g);
        }));
        b.add(back(this::guiList));
        dk().open(p, dk().multi(lang().t("dialogs.gui.add-title"),
                List.of(dk().message(lang().t("dialogs.gui.add-body"))), inputs, b, 2));
    }

    private boolean validAction(String a) {
        return a.equals("close") || a.startsWith("command:") && a.length() > 8
                || List.of("menu:main", "menu:play", "menu:cosmetics", "menu:stats", "menu:admin").contains(a);
    }

    private boolean applyGuiInputs(Player p, GuiButton g, DialogResponseView view) {
        String label = view.getText("label");
        if (label != null && !label.isBlank()) g.label = label.trim();
        String tip = view.getText("tooltip");
        if (tip != null) g.tooltip = tip.trim();
        Boolean en = view.getBoolean("enabled");
        if (en != null) g.enabled = en;
        Boolean adm = view.getBoolean("adminonly");
        if (adm != null) g.adminOnly = adm;
        String action = view.getText("action");
        if (action != null) {
            action = action.trim();
            if (!validAction(action)) {
                lang().send(p, "gui.invalid-action");
                return false;
            }
            g.action = action;
        }
        return true;
    }

    public void guiEdit(Player p, GuiButton g) {
        if (denied(p)) return;
        List<DialogBody> body = List.of(dk().message(lang().t("dialogs.gui-edit.body", ph("id", g.id))));
        List<DialogInput> inputs = new ArrayList<>();
        inputs.add(dk().text("label", lang().t("dialogs.gui-edit.label"), g.label, 200));
        inputs.add(dk().text("tooltip", lang().t("dialogs.gui-edit.tooltip"), g.tooltip, 200));
        inputs.add(dk().text("action", lang().t("dialogs.gui-edit.action"), g.action, 100));
        inputs.add(dk().bool("enabled", lang().t("dialogs.gui-edit.enabled"), g.enabled));
        inputs.add(dk().bool("adminonly", lang().t("dialogs.gui-edit.admin-only"), g.adminOnly));

        List<ActionButton> b = new ArrayList<>();
        b.add(dk().button(lang().t("dialogs.common.save"), null, (pl, view) -> {
            if (applyGuiInputs(pl, g, view)) {
                plugin.gui().save();
                lang().send(pl, "gui.saved", ph("id", g.id));
            }
            guiEdit(pl, g);
        }));
        b.add(dk().button(lang().t("dialogs.gui-edit.move-up"), null, (pl, view) -> {
            if (applyGuiInputs(pl, g, view)) plugin.gui().move(g, -1);
            guiEdit(pl, g);
        }));
        b.add(dk().button(lang().t("dialogs.gui-edit.move-down"), null, (pl, view) -> {
            if (applyGuiInputs(pl, g, view)) plugin.gui().move(g, 1);
            guiEdit(pl, g);
        }));
        b.add(dk().button(lang().t("dialogs.common.delete"), null, pl -> {
            plugin.gui().remove(g);
            lang().send(pl, "gui.deleted", ph("id", g.id));
            guiList(pl);
        }));
        b.add(back(this::guiList));
        dk().open(p, dk().multi(lang().t("dialogs.gui-edit.title", ph("id", g.id)), body, inputs, b, 2));
    }

    private String clean(String s) {
        return s == null ? "" : s.trim().toLowerCase().replace(' ', '_');
    }
}

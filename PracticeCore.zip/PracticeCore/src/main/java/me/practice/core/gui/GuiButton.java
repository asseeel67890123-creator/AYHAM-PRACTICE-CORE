package me.practice.core.gui;

public final class GuiButton {
    public final String id;
    /** MiniMessage text, or "lang:some.key" to read it from the language file */
    public String label;
    public String tooltip;
    /** menu:play | menu:cosmetics | menu:stats | menu:admin | command:<cmd> | close */
    public String action;
    public boolean enabled = true;
    public boolean adminOnly = false;

    public GuiButton(String id) {
        this.id = id;
        this.label = id;
        this.tooltip = "";
        this.action = "close";
    }
}

package me.practice.core.match;

import me.practice.core.arena.Arena;
import me.practice.core.kit.Kit;
import org.bukkit.scheduler.BukkitTask;

import java.util.UUID;

public final class Match {

    public enum State { COUNTDOWN, ACTIVE, ENDED }

    public final Kit kit;
    public final Arena arena;
    public final UUID a;
    public final UUID b;
    public State state = State.COUNTDOWN;
    public int counter;
    public int elapsed;
    public BukkitTask task;

    public Match(Kit kit, Arena arena, UUID a, UUID b) {
        this.kit = kit;
        this.arena = arena;
        this.a = a;
        this.b = b;
    }

    public UUID opponent(UUID self) {
        return self.equals(a) ? b : a;
    }

    public boolean has(UUID id) {
        return a.equals(id) || b.equals(id);
    }
}

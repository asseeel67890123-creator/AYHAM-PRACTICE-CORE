package me.practice.core;

import me.practice.core.arena.ArenaManager;
import me.practice.core.command.PracticeCommand;
import me.practice.core.cosmetics.CosmeticsManager;
import me.practice.core.dialog.AdminMenus;
import me.practice.core.dialog.DialogKit;
import me.practice.core.dialog.PlayerMenus;
import me.practice.core.gui.GuiManager;
import me.practice.core.kit.KitManager;
import me.practice.core.lang.LangManager;
import me.practice.core.listener.PracticeListener;
import me.practice.core.match.MatchManager;
import me.practice.core.profile.ProfileManager;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;

import java.io.File;
import java.io.IOException;
import java.util.List;

public final class PracticePlugin extends JavaPlugin {

    private LangManager lang;
    private ArenaManager arenas;
    private KitManager kits;
    private ProfileManager profiles;
    private GuiManager gui;
    private CosmeticsManager cosmetics;
    private MatchManager matches;
    private DialogKit dialogKit;
    private PlayerMenus playerMenus;
    private AdminMenus adminMenus;

    private NamespacedKey menuItemKey;
    private Location lobby;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        menuItemKey = new NamespacedKey(this, "menu_item");

        lang = new LangManager(this);
        arenas = new ArenaManager(this);
        kits = new KitManager(this);
        profiles = new ProfileManager(this);
        gui = new GuiManager(this);
        cosmetics = new CosmeticsManager(this);
        matches = new MatchManager(this);
        dialogKit = new DialogKit(this);
        playerMenus = new PlayerMenus(this);
        adminMenus = new AdminMenus(this);

        loadAll();

        getServer().getPluginManager().registerEvents(new PracticeListener(this), this);
        PracticeCommand cmd = new PracticeCommand(this);
        var pc = getCommand("practice");
        if (pc != null) {
            pc.setExecutor(cmd);
            pc.setTabCompleter(cmd);
        }

        for (Player p : Bukkit.getOnlinePlayers()) {
            profiles.touch(p);
            toLobby(p);
        }
    }

    @Override
    public void onDisable() {
        if (matches != null) matches.shutdown();
        if (profiles != null) profiles.save();
    }

    private void loadAll() {
        lang.load();
        arenas.load();
        kits.load();
        profiles.load();
        gui.load();
        loadData();
    }

    /** /practice reload */
    public void reloadAll() {
        reloadConfig();
        loadAll();
    }

    // ---------- lobby ----------

    private File dataFile() {
        return new File(getDataFolder(), "data.yml");
    }

    private void loadData() {
        lobby = YamlConfiguration.loadConfiguration(dataFile()).getLocation("lobby");
    }

    public void setLobby(Location loc) {
        lobby = loc.clone();
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(dataFile());
        cfg.set("lobby", lobby);
        try {
            cfg.save(dataFile());
        } catch (IOException e) {
            getLogger().severe("Could not save data.yml: " + e.getMessage());
        }
    }

    public Location lobby() {
        if (lobby != null && lobby.getWorld() != null) return lobby;
        return Bukkit.getWorlds().get(0).getSpawnLocation();
    }

    /** Resets a player and sends them to the lobby with the menu item. */
    public void toLobby(Player p) {
        p.closeDialog();
        p.setGameMode(GameMode.SURVIVAL);
        p.getInventory().clear();
        p.getInventory().setArmorContents(new ItemStack[4]);
        p.getInventory().setItemInOffHand(null);
        for (PotionEffect e : p.getActivePotionEffects()) p.removePotionEffect(e.getType());
        p.setFireTicks(0);
        p.setFallDistance(0f);
        p.setHealth(p.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue());
        p.setFoodLevel(20);
        p.setSaturation(20f);
        p.teleport(lobby());
        giveMenuItem(p);
    }

    private void giveMenuItem(Player p) {
        Material mat = Material.matchMaterial(getConfig().getString("lobby-items.menu-material", "COMPASS"));
        if (mat == null || !mat.isItem()) mat = Material.COMPASS;
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(lang.item("items.menu.name"));
        meta.lore(List.of(lang.item("items.menu.lore")));
        meta.getPersistentDataContainer().set(menuItemKey, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        int slot = Math.max(0, Math.min(8, getConfig().getInt("lobby-items.menu-slot", 4)));
        p.getInventory().setItem(slot, item);
    }

    public boolean isMenuItem(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer().has(menuItemKey, PersistentDataType.BYTE);
    }

    // ---------- accessors ----------

    public LangManager lang() { return lang; }
    public ArenaManager arenas() { return arenas; }
    public KitManager kits() { return kits; }
    public ProfileManager profiles() { return profiles; }
    public GuiManager gui() { return gui; }
    public CosmeticsManager cosmetics() { return cosmetics; }
    public MatchManager matches() { return matches; }
    public DialogKit dialogs() { return dialogKit; }
    public PlayerMenus playerMenus() { return playerMenus; }
    public AdminMenus adminMenus() { return adminMenus; }
}

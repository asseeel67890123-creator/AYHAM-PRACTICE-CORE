package me.practice.core.cosmetics;

import io.papermc.paper.registry.RegistryAccess;
import io.papermc.paper.registry.RegistryKey;
import me.practice.core.PracticePlugin;
import me.practice.core.profile.Profile;
import org.bukkit.DyeColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.block.Banner;
import org.bukkit.block.banner.Pattern;
import org.bukkit.block.banner.PatternType;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ArmorMeta;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.trim.ArmorTrim;
import org.bukkit.inventory.meta.trim.TrimMaterial;
import org.bukkit.inventory.meta.trim.TrimPattern;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Armor trim + shield customization. Applied to every kit item at match start. */
public final class CosmeticsManager {

    private final PracticePlugin plugin;

    public CosmeticsManager(PracticePlugin plugin) {
        this.plugin = plugin;
    }

    // ---------- registries ----------

    private Registry<TrimPattern> trimPatterns() {
        return RegistryAccess.registryAccess().getRegistry(RegistryKey.TRIM_PATTERN);
    }

    private Registry<TrimMaterial> trimMaterials() {
        return RegistryAccess.registryAccess().getRegistry(RegistryKey.TRIM_MATERIAL);
    }

    private Registry<PatternType> bannerPatterns() {
        return RegistryAccess.registryAccess().getRegistry(RegistryKey.BANNER_PATTERN);
    }

    public List<String> trimPatternIds() {
        return trimPatterns().stream().map(p -> trimPatterns().getKey(p).getKey()).sorted().toList();
    }

    public List<String> trimMaterialIds() {
        return trimMaterials().stream().map(p -> trimMaterials().getKey(p).getKey()).sorted().toList();
    }

    public List<String> bannerPatternIds() {
        return bannerPatterns().stream().map(p -> bannerPatterns().getKey(p).getKey()).sorted().toList();
    }

    public static List<String> dyeNames() {
        List<String> l = new ArrayList<>();
        for (DyeColor c : DyeColor.values()) l.add(c.name());
        return l;
    }

    public static String pretty(String id) {
        StringBuilder sb = new StringBuilder();
        for (String part : id.toLowerCase(Locale.ROOT).split("_")) {
            if (part.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return sb.toString();
    }

    // ---------- armor trim ----------

    public ArmorTrim buildTrim(Profile p) {
        if (p.trimPattern.equals("none") || p.trimMaterial.equals("none")) return null;
        TrimPattern pattern = trimPatterns().get(NamespacedKey.minecraft(p.trimPattern));
        TrimMaterial material = trimMaterials().get(NamespacedKey.minecraft(p.trimMaterial));
        if (pattern == null || material == null) return null;
        return new ArmorTrim(material, pattern);
    }

    // ---------- shield ----------

    public boolean hasShieldCustomization(Profile p) {
        return !p.shieldBase.equals("none") || !p.shieldLayers.isEmpty();
    }

    private DyeColor dye(String name, DyeColor def) {
        try {
            return DyeColor.valueOf(name.toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            return def;
        }
    }

    private List<Pattern> buildPatterns(Profile p) {
        List<Pattern> list = new ArrayList<>();
        for (String s : p.shieldLayers) {
            String[] parts = s.split(":");
            if (parts.length != 2) continue;
            PatternType type = bannerPatterns().get(NamespacedKey.minecraft(parts[0]));
            if (type == null) continue;
            list.add(new Pattern(dye(parts[1], DyeColor.WHITE), type));
        }
        return list;
    }

    // ---------- applying ----------

    /** Returns the same item with the player's trim / shield design applied when it fits. */
    public ItemStack decorate(ItemStack item, Profile p) {
        if (item == null || item.getType().isAir()) return item;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        if (meta instanceof ArmorMeta armor) {
            ArmorTrim trim = buildTrim(p);
            if (trim != null) {
                armor.setTrim(trim);
                item.setItemMeta(armor);
            }
        } else if (item.getType() == Material.SHIELD && hasShieldCustomization(p)
                && meta instanceof BlockStateMeta bsm && bsm.getBlockState() instanceof Banner banner) {
            if (!p.shieldBase.equals("none")) banner.setBaseColor(dye(p.shieldBase, DyeColor.WHITE));
            banner.setPatterns(buildPatterns(p));
            bsm.setBlockState(banner);
            item.setItemMeta(bsm);
        }
        return item;
    }

    /** Preview used inside the trim dialog. */
    public ItemStack previewTrim(Profile p) {
        return decorate(new ItemStack(Material.NETHERITE_CHESTPLATE), p);
    }

    /** Preview used inside the shield dialog. */
    public ItemStack previewShield(Profile p) {
        return decorate(new ItemStack(Material.SHIELD), p);
    }
}

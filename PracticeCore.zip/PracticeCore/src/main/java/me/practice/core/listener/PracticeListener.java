package me.practice.core.listener;

import me.practice.core.PracticePlugin;
import me.practice.core.match.Match;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.EquipmentSlot;

public final class PracticeListener implements Listener {

    private final PracticePlugin plugin;

    public PracticeListener(PracticePlugin plugin) {
        this.plugin = plugin;
    }

    private boolean builder(Player p) {
        return p.hasPermission("practice.admin") && p.getGameMode() == GameMode.CREATIVE;
    }

    // ---------- join / quit ----------

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        plugin.profiles().touch(e.getPlayer());
        plugin.toLobby(e.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        plugin.matches().handleQuit(e.getPlayer());
        plugin.profiles().save();
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        e.setRespawnLocation(plugin.lobby());
        plugin.getServer().getScheduler().runTask(plugin, () -> plugin.toLobby(e.getPlayer()));
    }

    // ---------- menu item ----------

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (!plugin.isMenuItem(e.getItem())) return;
        e.setCancelled(true);
        plugin.playerMenus().main(e.getPlayer());
    }

    // ---------- damage / match rules ----------

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        Match m = plugin.matches().matchOf(p);
        if (m == null || m.state != Match.State.ACTIVE) {
            e.setCancelled(true);
            return;
        }
        if (p.getHealth() - e.getFinalDamage() <= 0) {
            // no death screen: cancel and end the match instead
            e.setCancelled(true);
            plugin.matches().handleLethal(p);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Player victim)) return;
        Player attacker = null;
        if (e.getDamager() instanceof Player a) {
            attacker = a;
        } else if (e.getDamager() instanceof org.bukkit.entity.Projectile proj && proj.getShooter() instanceof Player a) {
            attacker = a;
        }
        if (attacker == null) return;
        Match m = plugin.matches().matchOf(victim);
        if (m == null || !m.has(attacker.getUniqueId())) e.setCancelled(true);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        // Safety net (e.g. /kill): never drop items, finish the match
        Player p = e.getEntity();
        if (plugin.matches().inMatch(p)) {
            e.setKeepInventory(true);
            e.getDrops().clear();
            e.setKeepLevel(true);
            e.setDroppedExp(0);
            e.deathMessage(null);
            plugin.matches().handleLethal(p);
        }
    }

    @EventHandler
    public void onFood(FoodLevelChangeEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        Match m = plugin.matches().matchOf(p);
        if (m == null || !m.kit.hunger) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onRegen(EntityRegainHealthEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        Match m = plugin.matches().matchOf(p);
        if (m == null || m.kit.regen) return;
        if (e.getRegainReason() == EntityRegainHealthEvent.RegainReason.SATIATED
                || e.getRegainReason() == EntityRegainHealthEvent.RegainReason.REGEN) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        Match m = plugin.matches().matchOf(e.getPlayer());
        if (m == null || m.state != Match.State.COUNTDOWN) return;
        var from = e.getFrom();
        var to = e.getTo();
        if (to == null) return;
        if (from.getX() != to.getX() || from.getZ() != to.getZ() || from.getY() != to.getY()) {
            to.setX(from.getX());
            to.setY(from.getY());
            to.setZ(from.getZ());
            e.setTo(to);
        }
    }

    // ---------- world protection ----------

    @EventHandler
    public void onBreak(BlockBreakEvent e) {
        if (!builder(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onPlace(BlockPlaceEvent e) {
        if (!builder(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent e) {
        if (!builder(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onSwap(PlayerSwapHandItemsEvent e) {
        if (!plugin.matches().inMatch(e.getPlayer()) && !builder(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onInvClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (!plugin.matches().inMatch(p) && !builder(p)) e.setCancelled(true);
    }
}

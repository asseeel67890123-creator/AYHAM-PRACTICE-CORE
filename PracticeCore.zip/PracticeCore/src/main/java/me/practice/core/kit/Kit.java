package me.practice.core.kit;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

public final class Kit {
    public final String id;
    public String displayName;
    public Material icon = Material.DIAMOND_SWORD;
    public boolean enabled = true;
    /** natural health regeneration from saturation */
    public boolean regen = true;
    /** hunger drains during the match */
    public boolean hunger = false;

    /** 36 slots: 0-8 hotbar, 9-35 main inventory */
    public ItemStack[] contents = new ItemStack[36];
    /** boots, leggings, chestplate, helmet */
    public ItemStack[] armor = new ItemStack[4];
    public ItemStack offhand;

    public Kit(String id) {
        this.id = id;
        this.displayName = id;
    }

    public int itemCount() {
        int n = 0;
        for (ItemStack i : contents) if (i != null && !i.getType().isAir()) n++;
        for (ItemStack i : armor) if (i != null && !i.getType().isAir()) n++;
        if (offhand != null && !offhand.getType().isAir()) n++;
        return n;
    }
}

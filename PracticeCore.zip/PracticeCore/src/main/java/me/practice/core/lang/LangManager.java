package me.practice.core.lang;

import me.practice.core.PracticePlugin;
import net.kyori.adventure.audience.Audience;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

/**
 * Loads plugins/PracticeCore/lang/<language>.yml.
 * Every text the plugin shows (chat, dialogs, buttons, items) comes from here.
 * Texts use MiniMessage and placeholders like <player>.
 */
public final class LangManager {

    private final PracticePlugin plugin;
    private final MiniMessage mm = MiniMessage.miniMessage();
    private YamlConfiguration lang = new YamlConfiguration();
    private YamlConfiguration fallback = new YamlConfiguration();

    public LangManager(PracticePlugin plugin) {
        this.plugin = plugin;
    }

    public void load() {
        for (String code : new String[]{"en", "ar"}) {
            File f = new File(plugin.getDataFolder(), "lang/" + code + ".yml");
            if (!f.exists()) plugin.saveResource("lang/" + code + ".yml", false);
        }
        String code = plugin.getConfig().getString("language", "en");
        File file = new File(plugin.getDataFolder(), "lang/" + code + ".yml");
        if (!file.exists()) {
            plugin.getLogger().warning("Language file '" + code + "' not found, using en.");
            file = new File(plugin.getDataFolder(), "lang/en.yml");
        }
        lang = YamlConfiguration.loadConfiguration(file);

        var in = plugin.getResource("lang/en.yml");
        fallback = in == null ? new YamlConfiguration()
                : YamlConfiguration.loadConfiguration(new InputStreamReader(in, StandardCharsets.UTF_8));
    }

    public String raw(String key) {
        String v = lang.getString(key);
        if (v == null) v = fallback.getString(key);
        return v == null ? key : v;
    }

    public static TagResolver ph(String name, Object value) {
        return Placeholder.unparsed(name, String.valueOf(value));
    }

    public static TagResolver phc(String name, Component value) {
        return Placeholder.component(name, value);
    }

    /** Component for a full key, e.g. dialogs.main.title */
    public Component t(String key, TagResolver... resolvers) {
        return mm.deserialize(raw(key), resolvers);
    }

    /** Same as t() but without the default italic (use for item names / lore). */
    public Component item(String key, TagResolver... resolvers) {
        return t(key, resolvers).decoration(TextDecoration.ITALIC, false);
    }

    /** Parses any MiniMessage text typed by an admin (kit names, gui labels). */
    public Component parse(String miniMessage, TagResolver... resolvers) {
        return mm.deserialize(miniMessage, resolvers);
    }

    /** Resolves "lang:some.key" to the language file, otherwise parses the text itself. */
    public Component parseOrLang(String text, TagResolver... resolvers) {
        if (text != null && text.startsWith("lang:")) return t(text.substring(5), resolvers);
        return parse(text == null ? "" : text, resolvers);
    }

    /** Chat message: prefix + messages.<key> */
    public Component msg(String key, TagResolver... resolvers) {
        return mm.deserialize(raw("prefix") + raw("messages." + key), resolvers);
    }

    public void send(Audience to, String key, TagResolver... resolvers) {
        to.sendMessage(msg(key, resolvers));
    }
}

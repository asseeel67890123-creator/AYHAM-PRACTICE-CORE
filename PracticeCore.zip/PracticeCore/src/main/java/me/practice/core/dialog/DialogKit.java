package me.practice.core.dialog;

import io.papermc.paper.dialog.Dialog;
import io.papermc.paper.dialog.DialogResponseView;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.DialogBase;
import io.papermc.paper.registry.data.dialog.action.DialogAction;
import io.papermc.paper.registry.data.dialog.body.DialogBody;
import io.papermc.paper.registry.data.dialog.input.DialogInput;
import io.papermc.paper.registry.data.dialog.input.SingleOptionDialogInput;
import io.papermc.paper.registry.data.dialog.type.DialogType;
import me.practice.core.PracticePlugin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickCallback;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;

/** Small helper around the Paper Dialog API so the menus stay readable. */
public final class DialogKit {

    public static final int BUTTON_WIDTH = 150;

    private final PracticePlugin plugin;
    private final ClickCallback.Options options =
            ClickCallback.Options.builder().uses(1).lifetime(Duration.ofMinutes(10)).build();

    public DialogKit(PracticePlugin plugin) {
        this.plugin = plugin;
    }

    // ---------- buttons ----------

    /** Button that runs code on click (the dialog closes afterwards, open a new one inside the code to "navigate"). */
    public ActionButton button(Component label, Component tooltip, Consumer<Player> onClick) {
        return button(label, tooltip, (p, view) -> onClick.accept(p));
    }

    /** Button that also receives the values of the dialog's inputs. */
    public ActionButton button(Component label, Component tooltip, BiConsumer<Player, DialogResponseView> onClick) {
        return ActionButton.create(label, tooltip, BUTTON_WIDTH, DialogAction.customClick((view, audience) -> {
            if (!(audience instanceof Player p)) return;
            if (Bukkit.isPrimaryThread()) {
                onClick.accept(p, view);
            } else {
                Bukkit.getScheduler().runTask(plugin, () -> onClick.accept(p, view));
            }
        }, options));
    }

    /** Button without action: it only closes the dialog. */
    public ActionButton closeButton(Component label) {
        return ActionButton.create(label, null, BUTTON_WIDTH, null);
    }

    // ---------- inputs ----------

    public DialogInput text(String key, Component label, String initial, int maxLength) {
        String init = initial == null ? "" : initial;
        if (init.length() > maxLength) init = init.substring(0, maxLength);
        return DialogInput.text(key, label).width(260).initial(init).maxLength(maxLength).build();
    }

    public DialogInput bool(String key, Component label, boolean initial) {
        return DialogInput.bool(key, label, initial, "true", "false");
    }

    /** Dropdown-style input; ids are the values you read back with view.getText(key). */
    public DialogInput options(String key, Component label, List<String> ids, String current,
                               Function<String, Component> display) {
        List<SingleOptionDialogInput.OptionEntry> entries = new ArrayList<>();
        boolean found = ids.contains(current);
        for (int i = 0; i < ids.size(); i++) {
            String id = ids.get(i);
            boolean initial = found ? id.equals(current) : i == 0;
            entries.add(SingleOptionDialogInput.OptionEntry.create(id, display.apply(id), initial));
        }
        return DialogInput.singleOption(key, label, entries).width(260).build();
    }

    // ---------- dialogs ----------

    public Dialog multi(Component title, List<DialogBody> body, List<DialogInput> inputs,
                        List<ActionButton> buttons, int columns) {
        DialogBase base = DialogBase.builder(title)
                .canCloseWithEscape(true)
                .body(body)
                .inputs(inputs)
                .build();
        return Dialog.create(b -> b.empty().base(base).type(DialogType.multiAction(buttons, null, columns)));
    }

    public Dialog confirm(Component title, Component message, ActionButton yes, ActionButton no) {
        DialogBase base = DialogBase.builder(title)
                .canCloseWithEscape(true)
                .body(List.of(DialogBody.plainMessage(message, 300)))
                .build();
        return Dialog.create(b -> b.empty().base(base).type(DialogType.confirmation(yes, no)));
    }

    public DialogBody message(Component c) {
        return DialogBody.plainMessage(c, 300);
    }

    public void open(Player p, Dialog dialog) {
        p.showDialog(dialog);
    }
}

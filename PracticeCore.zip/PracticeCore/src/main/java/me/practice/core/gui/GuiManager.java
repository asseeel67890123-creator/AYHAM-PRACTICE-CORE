package me.practice.core.gui;

import me.practice.core.PracticePlugin;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/** Holds the buttons of the main menu (gui.yml). Admins edit them in game. */
public final class GuiManager {

    private final PracticePlugin plugin;
    private final File file;
    private final List<GuiButton> buttons = new ArrayList<>();

    public GuiManager(PracticePlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "gui.yml");
    }

    public void load() {
        if (!file.exists()) createDefaults();
        buttons.clear();
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = cfg.getConfigurationSection("buttons");
        if (root == null) return;
        for (String id : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(id);
            if (s == null) continue;
            GuiButton b = new GuiButton(id);
            b.label = s.getString("label", id);
            b.tooltip = s.getString("tooltip", "");
            b.action = s.getString("action", "close");
            b.enabled = s.getBoolean("enabled", true);
            b.adminOnly = s.getBoolean("admin-only", false);
            buttons.add(b);
        }
    }

    private void createDefaults() {
        add(button("close", "lang:gui.defaults.close.label", "lang:gui.defaults.close.tooltip", "close", false));
        add(button("play", "lang:gui.defaults.play.label", "lang:gui.defaults.play.tooltip", "menu:play", false));
        add(button("cosmetics", "lang:gui.defaults.cosmetics.label", "lang:gui.defaults.cosmetics.tooltip", "menu:cosmetics", false));
        add(button("stats", "lang:gui.defaults.stats.label", "lang:gui.defaults.stats.tooltip", "menu:stats", false));
        add(button("admin", "lang:gui.defaults.admin.label", "lang:gui.defaults.admin.tooltip", "menu:admin", true));
        save();
    }

    private GuiButton button(String id, String label, String tooltip, String action, boolean admin) {
        GuiButton b = new GuiButton(id);
        b.label = label;
        b.tooltip = tooltip;
        b.action = action;
        b.adminOnly = admin;
        return b;
    }

    public void save() {
        YamlConfiguration cfg = new YamlConfiguration();
        for (GuiButton b : buttons) {
            String p = "buttons." + b.id + ".";
            cfg.set(p + "label", b.label);
            cfg.set(p + "tooltip", b.tooltip);
            cfg.set(p + "action", b.action);
            cfg.set(p + "enabled", b.enabled);
            cfg.set(p + "admin-only", b.adminOnly);
        }
        try {
            cfg.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("Could not save gui.yml: " + e.getMessage());
        }
    }

    public List<GuiButton> all() {
        return buttons;
    }

    public GuiButton get(String id) {
        for (GuiButton b : buttons) if (b.id.equalsIgnoreCase(id)) return b;
        return null;
    }

    public void add(GuiButton b) {
        buttons.add(b);
    }

    public void remove(GuiButton b) {
        buttons.remove(b);
        save();
    }

    public void move(GuiButton b, int delta) {
        int i = buttons.indexOf(b);
        int j = i + delta;
        if (i < 0 || j < 0 || j >= buttons.size()) return;
        buttons.remove(i);
        buttons.add(j, b);
        save();
    }

    public List<GuiButton> visibleFor(Player p) {
        boolean admin = p.hasPermission("practice.admin");
        List<GuiButton> l = new ArrayList<>();
        for (GuiButton b : buttons) {
            if (!b.enabled) continue;
            if (b.adminOnly && !admin) continue;
            l.add(b);
        }
        return l;
    }
}

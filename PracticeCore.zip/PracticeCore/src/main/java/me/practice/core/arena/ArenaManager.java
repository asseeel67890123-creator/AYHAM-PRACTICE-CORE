package me.practice.core.arena;

import me.practice.core.PracticePlugin;
import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class ArenaManager {

    private final PracticePlugin plugin;
    private final File file;
    private final Map<String, Arena> arenas = new LinkedHashMap<>();

    public ArenaManager(PracticePlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "arenas.yml");
    }

    public void load() {
        arenas.clear();
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = cfg.getConfigurationSection("arenas");
        if (root == null) return;
        for (String id : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(id);
            if (s == null) continue;
            Arena a = new Arena(id);
            a.displayName = s.getString("display", id);
            a.enabled = s.getBoolean("enabled", true);
            a.pos1 = s.getLocation("pos1");
            a.pos2 = s.getLocation("pos2");
            arenas.put(id, a);
        }
    }

    public void save() {
        YamlConfiguration cfg = new YamlConfiguration();
        for (Arena a : arenas.values()) {
            String p = "arenas." + a.id + ".";
            cfg.set(p + "display", a.displayName);
            cfg.set(p + "enabled", a.enabled);
            cfg.set(p + "pos1", a.pos1);
            cfg.set(p + "pos2", a.pos2);
        }
        try {
            cfg.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("Could not save arenas.yml: " + e.getMessage());
        }
    }

    public Collection<Arena> all() {
        return arenas.values();
    }

    public Arena get(String id) {
        return id == null ? null : arenas.get(id.toLowerCase());
    }

    public Arena create(String id) {
        Arena a = new Arena(id);
        arenas.put(id, a);
        save();
        return a;
    }

    public void delete(String id) {
        arenas.remove(id);
        save();
    }

    public List<Arena> readyArenas() {
        List<Arena> list = new ArrayList<>();
        for (Arena a : arenas.values()) if (a.ready()) list.add(a);
        return list;
    }

    public static String fmt(Location l) {
        if (l == null || l.getWorld() == null) return "-";
        return l.getWorld().getName() + " " + l.getBlockX() + ", " + l.getBlockY() + ", " + l.getBlockZ();
    }
}

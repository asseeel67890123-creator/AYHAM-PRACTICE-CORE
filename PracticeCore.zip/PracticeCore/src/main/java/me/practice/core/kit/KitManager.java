package me.practice.core.kit;

import me.practice.core.PracticePlugin;
import me.practice.core.cosmetics.CosmeticsManager;
import me.practice.core.profile.Profile;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class KitManager {

    private final PracticePlugin plugin;
    private final File file;
    private final Map<String, Kit> kits = new LinkedHashMap<>();

    public KitManager(PracticePlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "kits.yml");
    }

    public void load() {
        kits.clear();
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = cfg.getConfigurationSection("kits");
        if (root == null) return;
        for (String id : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(id);
            if (s == null) continue;
            Kit k = new Kit(id);
            k.displayName = s.getString("display", id);
            Material m = Material.matchMaterial(s.getString("icon", "DIAMOND_SWORD"));
            if (m != null && m.isItem()) k.icon = m;
            k.enabled = s.getBoolean("enabled", true);
            k.regen = s.getBoolean("regen", true);
            k.hunger = s.getBoolean("hunger", false);
            k.contents = readItems(s.getList("contents"), 36);
            k.armor = readItems(s.getList("armor"), 4);
            k.offhand = s.getItemStack("offhand");
            kits.put(id, k);
        }
    }

    private ItemStack[] readItems(List<?> list, int size) {
        ItemStack[] arr = new ItemStack[size];
        if (list == null) return arr;
        for (int i = 0; i < Math.min(size, list.size()); i++) {
            Object o = list.get(i);
            if (o instanceof ItemStack is) arr[i] = is;
        }
        return arr;
    }

    public void save() {
        YamlConfiguration cfg = new YamlConfiguration();
        for (Kit k : kits.values()) {
            String p = "kits." + k.id + ".";
            cfg.set(p + "display", k.displayName);
            cfg.set(p + "icon", k.icon.name());
            cfg.set(p + "enabled", k.enabled);
            cfg.set(p + "regen", k.regen);
            cfg.set(p + "hunger", k.hunger);
            cfg.set(p + "contents", new ArrayList<>(Arrays.asList(k.contents)));
            cfg.set(p + "armor", new ArrayList<>(Arrays.asList(k.armor)));
            cfg.set(p + "offhand", k.offhand);
        }
        try {
            cfg.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("Could not save kits.yml: " + e.getMessage());
        }
    }

    public Collection<Kit> all() {
        return kits.values();
    }

    public List<Kit> enabled() {
        List<Kit> l = new ArrayList<>();
        for (Kit k : kits.values()) if (k.enabled) l.add(k);
        return l;
    }

    public Kit get(String id) {
        return id == null ? null : kits.get(id.toLowerCase());
    }

    public Kit createFromPlayer(String id, Player p) {
        Kit k = new Kit(id);
        copyFromPlayer(k, p);
        kits.put(id, k);
        save();
        return k;
    }

    /** Takes the items the admin is currently holding/wearing as the kit layout. */
    public void copyFromPlayer(Kit k, Player p) {
        PlayerInventory inv = p.getInventory();
        k.contents = new ItemStack[36];
        for (int i = 0; i < 36; i++) {
            ItemStack it = inv.getItem(i);
            k.contents[i] = it == null ? null : it.clone();
        }
        k.armor = new ItemStack[4];
        ItemStack[] a = inv.getArmorContents();
        for (int i = 0; i < 4; i++) k.armor[i] = a[i] == null ? null : a[i].clone();
        ItemStack off = inv.getItemInOffHand();
        k.offhand = off.getType().isAir() ? null : off.clone();
    }

    public void delete(String id) {
        kits.remove(id);
        save();
    }

    /** Gives the kit to a player and applies the player's saved cosmetics. */
    public void apply(Player p, Kit k, Profile profile) {
        CosmeticsManager cos = plugin.cosmetics();
        PlayerInventory inv = p.getInventory();
        inv.clear();
        for (int i = 0; i < 36; i++) {
            ItemStack it = k.contents[i];
            if (it != null) inv.setItem(i, cos.decorate(it.clone(), profile));
        }
        ItemStack[] arm = new ItemStack[4];
        for (int i = 0; i < 4; i++) {
            ItemStack it = k.armor[i];
            if (it != null) arm[i] = cos.decorate(it.clone(), profile);
        }
        inv.setArmorContents(arm);
        if (k.offhand != null) inv.setItemInOffHand(cos.decorate(k.offhand.clone(), profile));
    }
}

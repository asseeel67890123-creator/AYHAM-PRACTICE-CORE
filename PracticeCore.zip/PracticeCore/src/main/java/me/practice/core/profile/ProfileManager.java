package me.practice.core.profile;

import me.practice.core.PracticePlugin;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class ProfileManager {

    private final PracticePlugin plugin;
    private final File file;
    private final Map<UUID, Profile> profiles = new HashMap<>();

    public ProfileManager(PracticePlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "profiles.yml");
    }

    public void load() {
        profiles.clear();
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = cfg.getConfigurationSection("players");
        if (root == null) return;
        for (String key : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(key);
            if (s == null) continue;
            UUID id;
            try {
                id = UUID.fromString(key);
            } catch (IllegalArgumentException e) {
                continue;
            }
            Profile p = new Profile(id, s.getString("name", "?"));
            p.wins = s.getInt("wins");
            p.losses = s.getInt("losses");
            p.streak = s.getInt("streak");
            p.bestStreak = s.getInt("best-streak");
            p.trimPattern = s.getString("trim-pattern", "none");
            p.trimMaterial = s.getString("trim-material", "none");
            p.shieldBase = s.getString("shield-base", "none");
            p.shieldLayers = new java.util.ArrayList<>(s.getStringList("shield-layers"));
            profiles.put(id, p);
        }
    }

    public void save() {
        YamlConfiguration cfg = new YamlConfiguration();
        for (Profile p : profiles.values()) {
            String b = "players." + p.id + ".";
            cfg.set(b + "name", p.name);
            cfg.set(b + "wins", p.wins);
            cfg.set(b + "losses", p.losses);
            cfg.set(b + "streak", p.streak);
            cfg.set(b + "best-streak", p.bestStreak);
            cfg.set(b + "trim-pattern", p.trimPattern);
            cfg.set(b + "trim-material", p.trimMaterial);
            cfg.set(b + "shield-base", p.shieldBase);
            cfg.set(b + "shield-layers", p.shieldLayers);
        }
        try {
            cfg.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("Could not save profiles.yml: " + e.getMessage());
        }
    }

    public Profile get(Player player) {
        return profiles.computeIfAbsent(player.getUniqueId(), id -> new Profile(id, player.getName()));
    }

    public Profile byId(UUID id) {
        return profiles.get(id);
    }

    public void touch(Player player) {
        get(player).name = player.getName();
    }
}
